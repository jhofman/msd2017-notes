Use this template to create your notes.

Open the `template.tex` file and follow these three main steps:

   1. Edit the lecture title
   2. Edit your name and the date
   3. Rename `uni.tex` to match your uni, edit the filename accordingly below, and put your notes in this file

Then write your notes in the renamed `uni.tex` file.

If you're new to LaTeX, check out [Overleaf](http://overleaf.com), an online LaTeX environment where you can edit and render your documents.
They also have a very useful [getting started guide](http://www.overleaf.com/help/18-how-do-i-use-overleaf).
